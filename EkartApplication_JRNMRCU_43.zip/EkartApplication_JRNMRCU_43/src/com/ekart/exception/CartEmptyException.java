package com.ekart.exception;

public class CartEmptyException extends Exception{


	private static final long serialVersionUID = 1L;

	
	
}
